-- Annotation [ent9]
alter table "public"."annotation"  add column  "itemid"  int4;


