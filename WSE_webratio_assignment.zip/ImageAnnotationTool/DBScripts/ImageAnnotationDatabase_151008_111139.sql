-- Campaign [ent4]
alter table "public"."campaign"  add column  "open"  bool;


