-- Excecution [ent7]
alter table "public"."excecution"  add column  "taskid"  int4;
alter table "public"."excecution"  add column  "workerid"  int4;


