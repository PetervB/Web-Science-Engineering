-- Task [ent3]
alter table "public"."task"  add column  "workerid"  int4;
alter table "public"."task"  add column  "reward_2"  numeric(19, 2);


-- Worker_Skills [rel3]
alter table "public"."worker"  add column  "skill_oid"  int4;
alter table "public"."worker"   add constraint fk_worker_skill foreign key ("skill_oid") references "public"."skill" ("oid");


-- Item_Task [rel4]
alter table "public"."task"  add column  "item_oid"  int4;
alter table "public"."task"   add constraint fk_task_item foreign key ("item_oid") references "public"."item" ("oid");


-- Task_Skill [rel9]
alter table "public"."task"  add column  "skill_oid_2"  int4;
alter table "public"."task"   add constraint fk_task_skill foreign key ("skill_oid_2") references "public"."skill" ("oid");


