-- Annotation [ent9]
alter table "public"."annotation"   drop column  "itemid";
