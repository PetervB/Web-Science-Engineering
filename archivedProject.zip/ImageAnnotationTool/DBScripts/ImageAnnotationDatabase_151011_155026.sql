-- Task [ent3]
alter table "public"."task"  add column  "status"  int4;


