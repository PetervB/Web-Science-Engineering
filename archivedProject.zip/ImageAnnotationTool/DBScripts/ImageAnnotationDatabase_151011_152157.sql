-- Task [ent3]
alter table "public"."task"  add column  "campaignid"  int4;


